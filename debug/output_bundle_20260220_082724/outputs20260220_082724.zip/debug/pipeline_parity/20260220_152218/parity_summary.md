# Pipeline Parity Summary

- Status: **pass**
- Generated UTC: `2026-02-20T15:23:11.782993+00:00`
- Baseline: `/Users/blocke/Box Sync/Residency Personal Files/Scholarly Work/Locke Research Projects/Hypercap-CC-NLP/artifacts/baselines/jupyter/20260220_152137_post_residual_integrity`
- Findings: P0=0, P1=0, P2=0

## Metric Drift
- icu_link_rate: baseline=0.7677753266587477, current=0.7677753266587477, severity=ok
- pct_any_gas_0_6h: baseline=0.41897166129305957, current=0.41897166129305957, severity=ok
- pct_any_gas_0_24h: baseline=0.9590191752927202, current=0.9590191752927202, severity=ok
- gas_source_other_rate: baseline=0.6617519019140463, current=0.6617519019140463, severity=ok

## Findings
- None.
